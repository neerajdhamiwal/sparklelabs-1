(function ($) {
// your standard jquery code goes here with $ prefix
// best used inside a page with inline code,
// or outside the document ready, enter code here

    $(document).ready(function () {
       
       var pid = jQuery("#edit-share-title-select option:selected").val();
       $("#product-"+pid+"-wrapper").show().siblings("div").hide();

       $("#edit-share-title-select").change(function() {
          var pid = jQuery("#edit-share-title-select option:selected").val();
         $("#product-"+pid+"-wrapper").show().siblings("div").hide();
       });

    });
})(jQuery);
