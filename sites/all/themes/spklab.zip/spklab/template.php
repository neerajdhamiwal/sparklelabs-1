<?php
/**
 * @file
 * The primary PHP file for this theme.
 */
function spklab_preprocess_page(&$vars, $hook = null){
    if (isset($vars['node'])) {
        switch ($vars['node']->type) {
            case 'invoice': // machine name content type
                drupal_add_js(drupal_get_path('theme', 'spklab').'/js/jspdf.min.js');
                drupal_add_js(drupal_get_path('theme', 'spklab').'/js/html2canvas.min.js');
                break;
        }
    }
}

function spklab_commerce_cart_empty_page() {
	if(isset($_SERVER['HTTP_REFERER'])) {
	    $referrer = $_SERVER['HTTP_REFERER'];
	}
	//echo $referrer;exit;
	if(empty($referrer)){
		$referrer = '/content/shop';
	}
	$ref_args = explode('/', $referrer);
	//echo $referrer."<pre>";print_r($ref_args);echo "</pre>";exit;
	if(current_path() == end($ref_args)){
		$referrer = '/content/shop';
	}
	//echo current_path();exit;
	//echo $referrer;exit;
    return '<div class="cart-empty-page"><div id="cart-view-main"><div id="cart-view-main-title"><h2>Your Bag (0) items</h2></div><p>Your shopping bag is empty.</p><a class="btn btn-default" href="'.$referrer.'">CONTINUE SHOPPING</a></div><div id="block-block-15" class="col-sm-4 block block-block"><h2 class="block-title">Adorable Gift wrapping</h2><p>Lorem ipsum dolor sit amet. dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. Incididunt ut labore et dolore magna aliqua</p></div><div id="block-views-cart-view-block">'.views_embed_view('cart_view', $display_id = 'block').'</div>';
}